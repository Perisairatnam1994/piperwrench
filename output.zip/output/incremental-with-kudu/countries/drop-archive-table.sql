
DROP TABLE IF EXISTS `user_srperi`.`arch_countries` PURGE;