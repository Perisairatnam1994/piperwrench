#!/usr/bin/env bash

set -euo pipefail

sqoop job --exec 'phdata-oracle-incremental/dev/countries'
