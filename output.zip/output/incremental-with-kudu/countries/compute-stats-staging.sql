
COMPUTE INCREMENTAL STATS `user_srperi`.`stg_countries`;