
DROP TABLE IF EXISTS `user_srperi`.`countries` PURGE;