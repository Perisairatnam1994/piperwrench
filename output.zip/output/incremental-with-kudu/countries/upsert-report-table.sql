
set sync_ddl=1;
REFRESH `user_srperi`.`stg_countries`;
UPSERT INTO `user_srperi`.`countries` SELECT
`country_id`,
`country_name`,
`region_id`
FROM `user_srperi`.`countries` ORDER BY `ID` ASC;