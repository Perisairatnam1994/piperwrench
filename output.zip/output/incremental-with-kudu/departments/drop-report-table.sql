
DROP TABLE IF EXISTS `user_srperi`.`departments` PURGE;