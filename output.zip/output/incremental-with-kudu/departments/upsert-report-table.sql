
set sync_ddl=1;
REFRESH `user_srperi`.`stg_departments`;
UPSERT INTO `user_srperi`.`departments` SELECT
`department_id`,
`department_name`,
`manager_id`,
`location_id`
FROM `user_srperi`.`departments` ORDER BY `ID` ASC;