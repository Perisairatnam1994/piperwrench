#!/usr/bin/env bash

set -euo pipefail

sqoop job -D 'sqoop.metastore.client.record.password=true'  -D 'mapreduce.job.name=Sqoop Incremental Job - name: phdata-oracle-incremental environment: dev table: departments' \
	--create 'phdata-oracle-incremental/dev/departments' \
	-- import \
	--driver 'oracle.jdbc.OracleDriver' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--target-dir 'hdfs:///user/srperi/db/stg_departments/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_departments/' \
	--incremental append \
	--append \
 	--check-column ID \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress  \
	--compression-codec snappy \
	-m 1 \
	--query 'SELECT
DEPARTMENT_ID AS department_id,
DEPARTMENT_NAME AS department_name,
MANAGER_ID AS manager_id,
LOCATION_ID AS location_id
FROM HR.DEPARTMENTS
WHERE $CONDITIONS'
