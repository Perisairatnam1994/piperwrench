export HADOOP_CLASSPATH="/opt/cloudera/parcels/PULSE/lib/appenders/*"
export HADOOP_OPTS="-Dlog4j.configuration=file:/home/srperi/pipewrench-2.1.0/log4j.properties"
spark-submit --deploy-mode client \
 --master local[*] \
--files /home/srperi/pipewrench-2.1.0/log4j-spark.properties \
--jars /opt/cloudera/parcels/PULSE/lib/appenders/log-appender-assembly-2.4.1.jar \
--conf "spark.driver.extraJavaOptions=-Dlog4j.configuration=log4j-spark.properties" \
--conf "spark.executor.extraJavaOptions=-Dlog4j.configuration=log4j-spark.properties" \
--class io.phdata.pipewrench.dq.DataQualityApp  ~/pipewrench-2.1.0/lib/pipewrench-data-quality-0.1-SNAPSHOT.jar \
--conf ~/pipewrench-2.1.0/output/phdata-oracle-incremental-pipeline/pipewrench-configuration.yml \
--table /home/srperi/pipewrench-2.1.0/output/incremental-with-kudu/departments

export PULSE_COLLECTOR_HOST="http://edge2.valhalla.phdata.io:9004"
export PULSE_COLLECTOR_PORT=9004
CWD="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

source $CWD/logger.sh

value=$?

if [ "$value" -eq 0 ] ; then
        logger --category=category --level=INFO --message="Data validation passed" --threadName=1 --application=data_validation
        #logger.error("data validation app passed")
else
        logger --caotegory=category --level=ERROR --message="Data validation failed" --threadName=1 --application=data_validation
        #logger.error("data validation app failed")
fi

