
INVALIDATE METADATA `user_srperi`.`arch_departments`;