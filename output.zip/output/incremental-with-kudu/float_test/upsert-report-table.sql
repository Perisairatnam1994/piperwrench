
set sync_ddl=1;
REFRESH `user_srperi`.`stg_float_test`;
UPSERT INTO `user_srperi`.`float_test` SELECT
`id`,
`float_value`
FROM `user_srperi`.`float_test` ORDER BY `ID` ASC;