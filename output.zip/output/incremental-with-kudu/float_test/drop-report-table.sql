
DROP TABLE IF EXISTS `user_srperi`.`float_test` PURGE;