
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`float_test` (
		`id` string COMMENT 'Primary Key',
		`float_value` float COMMENT 'Float value',
PRIMARY KEY (`ID`)
)

PARTITION BY HASH (`ID`) PARTITIONS 2
COMMENT 'Testing float values in Oracle tables'
STORED AS KUDU
;

