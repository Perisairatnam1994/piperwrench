#!/usr/bin/env bash

set -euo pipefail

sqoop job -D 'sqoop.metastore.client.record.password=true'  -D 'mapreduce.job.name=Sqoop Incremental Job - name: phdata-oracle-incremental environment: dev table: float_test' \
	--create 'phdata-oracle-incremental/dev/float_test' \
	-- import \
	--driver 'oracle.jdbc.OracleDriver' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--target-dir 'hdfs:///user/srperi/db/stg_float_test/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_float_test/' \
	--incremental append \
	--append \
	--map-column-java float_value=Float \
 	--check-column ID \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress  \
	--compression-codec snappy \
	-m 1 \
	--query 'SELECT
ID AS "id",
FLOAT_VALUE AS "float_value"
FROM HR.FLOAT_TEST
WHERE $CONDITIONS'