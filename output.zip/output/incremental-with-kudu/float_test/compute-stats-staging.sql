
COMPUTE INCREMENTAL STATS `user_srperi`.`stg_float_test`;