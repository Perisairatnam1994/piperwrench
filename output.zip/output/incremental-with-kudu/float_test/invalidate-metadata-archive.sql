
INVALIDATE METADATA `user_srperi`.`arch_float_test`;