
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`jobs` (
		`job_id` string COMMENT 'Primary key of jobs table.',
		`job_title` string COMMENT 'A not null column that shows job title, e.g. AD_VP, FI_ACCOUNTANT',
		`min_salary` int COMMENT 'Minimum salary for a job title.',
		`max_salary` int COMMENT 'Maximum salary for a job title',
PRIMARY KEY (`JOB_ID`)
)

PARTITION BY HASH (`JOB_ID`) PARTITIONS 2
COMMENT 'jobs table with job titles and salary ranges. Contains 19 rows.
References with employees and job_history table.'
STORED AS KUDU
;

