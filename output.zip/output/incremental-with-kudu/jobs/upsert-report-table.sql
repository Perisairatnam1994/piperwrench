
set sync_ddl=1;
REFRESH `user_srperi`.`stg_jobs`;
UPSERT INTO `user_srperi`.`jobs` SELECT
`job_id`,
`job_title`,
`min_salary`,
`max_salary`
FROM `user_srperi`.`jobs` ORDER BY `ID` ASC;