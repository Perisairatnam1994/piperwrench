
COMPUTE INCREMENTAL STATS `user_srperi`.`jobs`;