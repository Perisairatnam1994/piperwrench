
DROP TABLE IF EXISTS `user_srperi`.`arch_jobs` PURGE;