
COMPUTE INCREMENTAL STATS `user_srperi`.`job_history`;