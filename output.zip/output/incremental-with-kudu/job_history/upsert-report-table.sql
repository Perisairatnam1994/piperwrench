
set sync_ddl=1;
REFRESH `user_srperi`.`stg_job_history`;
UPSERT INTO `user_srperi`.`job_history` SELECT
`employee_id`,
`start_date`,
`end_date`,
`job_id`,
`department_id`
FROM `user_srperi`.`job_history` ORDER BY `ID` ASC;