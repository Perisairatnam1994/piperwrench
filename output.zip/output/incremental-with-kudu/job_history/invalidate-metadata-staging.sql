
INVALIDATE METADATA `user_srperi`.`stg_job_history`;