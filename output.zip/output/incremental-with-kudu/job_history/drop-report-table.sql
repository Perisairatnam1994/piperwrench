
DROP TABLE IF EXISTS `user_srperi`.`job_history` PURGE;