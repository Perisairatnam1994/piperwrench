
COMPUTE INCREMENTAL STATS `user_srperi`.`stg_job_history`;