#!/bin/bash


set -euo pipefail

sqoop job --delete 'phdata-oracle-incremental/dev/job_history'