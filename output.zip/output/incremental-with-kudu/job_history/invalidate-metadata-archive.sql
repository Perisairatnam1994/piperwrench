
INVALIDATE METADATA `user_srperi`.`arch_job_history`;