
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`job_history` (
		`employee_id` int COMMENT 'A not null column in the complex primary key employee_id+start_date.
Foreign key to employee_id column of the employee table',
		`start_date` bigint COMMENT 'A not null column in the complex primary key employee_id+start_date.
Must be less than the end_date of the job_history table. (enforced by
constraint jhist_date_interval)',
		`end_date` bigint COMMENT 'Last day of the employee in this job role. A not null column. Must be
greater than the start_date of the job_history table.
(enforced by constraint jhist_date_interval)',
		`job_id` string COMMENT 'Job role in which the employee worked in the past; foreign key to
job_id column in the jobs table. A not null column.',
		`department_id` int COMMENT 'Department id in which the employee worked in the past; foreign key to deparment_id column in the departments table',
PRIMARY KEY (`EMPLOYEE_ID`,`START_DATE`)
)

PARTITION BY HASH (`EMPLOYEE_ID`,`START_DATE`) PARTITIONS 2
COMMENT 'Table that stores job history of the employees. If an employee
changes departments within the job or changes jobs within the department,
new rows get inserted into this table with old job information of the
employee. Contains a complex primary key: employee_id+start_date.
Contains 25 rows. References with jobs, employees, and departments tables.'
STORED AS KUDU
;

