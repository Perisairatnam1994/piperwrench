#!/usr/bin/env bash

set -euo pipefail

sqoop job -D 'sqoop.metastore.client.record.password=true'  -D 'mapreduce.job.name=Sqoop Incremental Job - name: phdata-oracle-incremental environment: dev table: job_history' \
	--create 'phdata-oracle-incremental/dev/job_history' \
	-- import \
	--driver 'oracle.jdbc.OracleDriver' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--target-dir 'hdfs:///user/srperi/db/stg_job_history/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_job_history/' \
	--incremental append \
	--append \
	--map-column-java employee_id=Integer,department_id=Integer \
 	--check-column ID \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress  \
	--compression-codec snappy \
	-m 1 \
	--query 'SELECT
EMPLOYEE_ID AS "employee_id",
START_DATE AS "start_date",
END_DATE AS "end_date",
JOB_ID AS "job_id",
DEPARTMENT_ID AS "department_id"
FROM HR.JOB_HISTORY
WHERE $CONDITIONS'