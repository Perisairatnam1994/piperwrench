#!/bin/bash

set -euo pipefail

INGEST_DATE=`date +"%Y-%m-%d_%H-%M-%S"`

hdfs dfs -mkdir -p hdfs:///user/srperi/db/arch_job_history/ingest_date=$INGEST_DATE
hdfs dfs -mv hdfs:///user/srperi/db/stg_job_history/*.avro hdfs:///user/srperi/db/arch_job_history/ingest_date=$INGEST_DATE/.

impala-shell -i worker1.valhalla.phdata.io -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/x509/truststore.pem -q "ALTER TABLE \`user_srperi\`.\`arch_job_history\` ADD PARTITION (ingest_date='$INGEST_DATE');"