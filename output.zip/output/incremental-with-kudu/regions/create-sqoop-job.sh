#!/usr/bin/env bash

set -euo pipefail

sqoop job -D 'sqoop.metastore.client.record.password=true'  -D 'mapreduce.job.name=Sqoop Incremental Job - name: phdata-oracle-incremental environment: dev table: regions' \
	--create 'phdata-oracle-incremental/dev/regions' \
	-- import \
	--driver 'oracle.jdbc.OracleDriver' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--target-dir 'hdfs:///user/srperi/db/stg_regions/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_regions/' \
	--incremental append \
	--append \
 	--check-column ID \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress  \
	--compression-codec snappy \
	-m 1 \
	--query 'SELECT
REGION_ID AS "region_id",
REGION_NAME AS "region_name"
FROM HR.REGIONS
WHERE $CONDITIONS'