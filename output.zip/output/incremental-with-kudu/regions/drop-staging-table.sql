
DROP TABLE IF EXISTS `user_srperi`.`stg_regions` PURGE;