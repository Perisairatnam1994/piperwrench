
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`arch_regions` (
`region_id` string COMMENT '',
`region_name` string COMMENT ''
)
PARTITIONED BY (ingest_date STRING)
COMMENT ''
STORED AS AVRO
LOCATION 'hdfs:///user/srperi/db/arch_regions'
TBLPROPERTIES(
'avro.schema.url' = 'hdfs:///user/srperi/db/arch_regions/.meta/arch_regions.avsc'
)