
COMPUTE INCREMENTAL STATS `user_srperi`.`regions`;