
DROP TABLE IF EXISTS `user_srperi`.`regions` PURGE;