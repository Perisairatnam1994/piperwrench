
INVALIDATE METADATA `user_srperi`.`arch_regions`;