
set sync_ddl=1;
REFRESH `user_srperi`.`stg_regions`;
UPSERT INTO `user_srperi`.`regions` SELECT
`region_id`,
`region_name`
FROM `user_srperi`.`regions` ORDER BY `ID` ASC;