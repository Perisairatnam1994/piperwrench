
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`stg_regions` (
`region_id` string COMMENT '',
`region_name` string COMMENT ''
)
COMMENT ''
STORED AS AVRO
LOCATION 'hdfs:///user/srperi/db/stg_regions'
TBLPROPERTIES(
'avro.schema.url' = 'hdfs:///user/srperi/db/stg_regions/.meta/stg_regions.avsc'
)