
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`regions` (
		`region_id` string COMMENT '',
		`region_name` string COMMENT '',
PRIMARY KEY (`REGION_ID`)
)

PARTITION BY HASH (`REGION_ID`) PARTITIONS 2
COMMENT ''
STORED AS KUDU
;

