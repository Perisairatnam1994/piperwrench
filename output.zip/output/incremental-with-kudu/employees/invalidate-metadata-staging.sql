
INVALIDATE METADATA `user_srperi`.`stg_employees`;