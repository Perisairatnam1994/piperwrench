#!/usr/bin/env bash

set -euo pipefail

sqoop job -D 'sqoop.metastore.client.record.password=true'  -D 'mapreduce.job.name=Sqoop Incremental Job - name: phdata-oracle-incremental environment: dev table: employees' \
	--create 'phdata-oracle-incremental/dev/employees' \
	-- import \
	--driver 'oracle.jdbc.OracleDriver' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--target-dir 'hdfs:///user/srperi/db/stg_employees/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_employees/' \
	--incremental append \
	--append \
	--map-column-java employee_id=Integer,manager_id=Integer,department_id=Integer \
 	--check-column ID \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress  \
	--compression-codec snappy \
	-m 1 \
	--query 'SELECT
EMPLOYEE_ID AS "employee_id",
FIRST_NAME AS "first_name",
LAST_NAME AS "last_name",
EMAIL AS "email",
PHONE_NUMBER AS "phone_number",
HIRE_DATE AS "hire_date",
JOB_ID AS "job_id",
SALARY AS "salary",
COMMISSION_PCT AS "commission_pct",
MANAGER_ID AS "manager_id",
DEPARTMENT_ID AS "department_id"
FROM HR.EMPLOYEES
WHERE $CONDITIONS'