
DROP TABLE IF EXISTS `user_srperi`.`employees` PURGE;