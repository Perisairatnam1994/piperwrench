
COMPUTE INCREMENTAL STATS `user_srperi`.`employees`;