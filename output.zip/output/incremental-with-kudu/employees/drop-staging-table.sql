
DROP TABLE IF EXISTS `user_srperi`.`stg_employees` PURGE;