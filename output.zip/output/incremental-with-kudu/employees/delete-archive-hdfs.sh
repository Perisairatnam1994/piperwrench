#!/usr/bin/env bash

set -euo pipefail

DIRECTORY="hdfs:///user/srperi/db/arch_employees"

if $(hdfs dfs -test -d $DIRECTORY); then
	hdfs dfs -rm -r -f $DIRECTORY
else
	echo "Directory: $DIRECTORY does not exist, nothing to delete"
fi