
set sync_ddl=1;
REFRESH `user_srperi`.`stg_employees`;
UPSERT INTO `user_srperi`.`employees` SELECT
`employee_id`,
`first_name`,
`last_name`,
`email`,
`phone_number`,
`hire_date`,
`job_id`,
`salary`,
`commission_pct`,
`manager_id`,
`department_id`
FROM `user_srperi`.`employees` ORDER BY `ID` ASC;