
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`locations` (
		`location_id` int COMMENT 'Primary key of locations table',
		`street_address` string COMMENT 'Street address of an office, warehouse, or production site of a company.
Contains building number and street name',
		`postal_code` string COMMENT 'Postal code of the location of an office, warehouse, or production site
of a company.',
		`city` string COMMENT 'A not null column that shows city where an office, warehouse, or
production site of a company is located.',
		`state_province` string COMMENT 'State or Province where an office, warehouse, or production site of a
company is located.',
		`country_id` string COMMENT 'Country where an office, warehouse, or production site of a company is
located. Foreign key to country_id column of the countries table.',
PRIMARY KEY (`LOCATION_ID`)
)

PARTITION BY HASH (`LOCATION_ID`) PARTITIONS 2
COMMENT 'Locations table that contains specific address of a specific office,
warehouse, and/or production site of a company. Does not store addresses /
locations of customers. Contains 23 rows; references with the
departments and countries tables.'
STORED AS KUDU
;

