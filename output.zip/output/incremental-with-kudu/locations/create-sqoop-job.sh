#!/usr/bin/env bash

set -euo pipefail

sqoop job -D 'sqoop.metastore.client.record.password=true'  -D 'mapreduce.job.name=Sqoop Incremental Job - name: phdata-oracle-incremental environment: dev table: locations' \
	--create 'phdata-oracle-incremental/dev/locations' \
	-- import \
	--driver 'oracle.jdbc.OracleDriver' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--target-dir 'hdfs:///user/srperi/db/stg_locations/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_locations/' \
	--incremental append \
	--append \
	--map-column-java location_id=Integer \
 	--check-column ID \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress  \
	--compression-codec snappy \
	-m 1 \
	--query 'SELECT
LOCATION_ID AS "location_id",
STREET_ADDRESS AS "street_address",
POSTAL_CODE AS "postal_code",
CITY AS "city",
STATE_PROVINCE AS "state_province",
COUNTRY_ID AS "country_id"
FROM HR.LOCATIONS
WHERE $CONDITIONS'