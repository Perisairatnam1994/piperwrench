
set sync_ddl=1;
REFRESH `user_srperi`.`stg_locations`;
UPSERT INTO `user_srperi`.`locations` SELECT
`location_id`,
`street_address`,
`postal_code`,
`city`,
`state_province`,
`country_id`
FROM `user_srperi`.`locations` ORDER BY `ID` ASC;