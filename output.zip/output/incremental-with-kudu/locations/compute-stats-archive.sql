
COMPUTE INCREMENTAL STATS `user_srperi`.`arch_locations`;