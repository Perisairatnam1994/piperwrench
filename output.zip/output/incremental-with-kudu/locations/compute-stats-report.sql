
COMPUTE INCREMENTAL STATS `user_srperi`.`locations`;