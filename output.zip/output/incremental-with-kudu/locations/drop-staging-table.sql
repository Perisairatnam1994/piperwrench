
DROP TABLE IF EXISTS `user_srperi`.`stg_locations` PURGE;