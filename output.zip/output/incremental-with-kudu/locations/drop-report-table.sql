
DROP TABLE IF EXISTS `user_srperi`.`locations` PURGE;