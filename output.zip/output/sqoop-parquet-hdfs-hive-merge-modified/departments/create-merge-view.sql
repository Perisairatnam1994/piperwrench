
set sync_ddl=1;

USE `user_srperi`;

--Create merged view --
DROP VIEW IF EXISTS `user_srperi`.`merge_view_departments`;




CREATE VIEW `user_srperi`.`merge_view_departments` AS
  SELECT t1.*
  FROM (SELECT * FROM `user_srperi`.`base_departments`
		UNION ALL
		SELECT * FROM `user_srperi`.`incr_departments`) t1
  JOIN (SELECT DEPARTMENT_ID, max(DEPARTMENT_ID) max_modified
		FROM (SELECT * FROM `user_srperi`.`base_departments`
		   UNION ALL
		SELECT * FROM `user_srperi`.`incr_departments`) t2
		GROUP BY DEPARTMENT_ID) s
  ON
				t1.DEPARTMENT_ID=s.DEPARTMENT_ID AND
			t1.DEPARTMENT_ID = s.max_modified;
