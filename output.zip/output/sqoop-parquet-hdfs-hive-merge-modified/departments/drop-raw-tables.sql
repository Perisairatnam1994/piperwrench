



DROP TABLE IF EXISTS `user_srperi`.`base_departments` PURGE;
DROP TABLE IF EXISTS `user_srperi`.`incr_departments` PURGE;
DROP VIEW IF EXISTS `user_srperi`.`merge_view_departments`;
