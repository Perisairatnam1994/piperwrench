#!/usr/bin/env bash

set -euo pipefail
sqoop job --delete 'pipeline/dev/departments'
sqoop job -D 'sqoop.metastore.client.record.password=true'  -D 'mapreduce.job.name=Sqoop Incremental Job merge - name: pipeline environment: dev table: departments' \
	--create 'pipeline/dev/departments' \
	-- import \
	--driver 'oracle.jdbc.OracleDriver' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521/ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--target-dir 'hdfs:///user/srperi/db/incr_departments/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/incr_departments/' \
		--incremental append \
	--append \
	--map-column-java DEPARTMENT_ID=Integer,MANAGER_ID=Integer,LOCATION_ID=Integer \
	   --check-column DEPARTMENT_ID \
	--as-parquetfile \
	--fetch-size 10000 \
	--compress  \
	--compression-codec snappy \
	-m 1 \
	--query 'SELECT
DEPARTMENT_ID AS DEPARTMENT_ID,
DEPARTMENT_NAME AS DEPARTMENT_NAME,
MANAGER_ID AS MANAGER_ID,
LOCATION_ID AS LOCATION_ID
FROM HR.DEPARTMENTS
WHERE $CONDITIONS'
