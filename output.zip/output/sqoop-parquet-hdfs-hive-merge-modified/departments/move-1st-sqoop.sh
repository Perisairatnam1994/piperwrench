#!/usr/bin/env bash




set -euo pipefail
hdfs dfs -mv hdfs:///user/srperi/db/incr_departments/*  hdfs:///user/srperi/db/base_departments

