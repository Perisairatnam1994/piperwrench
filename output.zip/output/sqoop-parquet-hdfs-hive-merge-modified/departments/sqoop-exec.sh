#!/usr/bin/env bash

set -euo pipefail

sqoop job --exec 'pipeline/dev/departments'

