


DROP TABLE IF EXISTS `user_srperi`.`report_departments`
PURGE;
