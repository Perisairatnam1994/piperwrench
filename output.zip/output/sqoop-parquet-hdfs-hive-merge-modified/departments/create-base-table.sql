
set sync_ddl=1;
USE `user_srperi`;

CREATE EXTERNAL TABLE IF NOT EXISTS `base_departments` (
  `department_id` int COMMENT 'Primary key column of departments table.',
`department_name` string COMMENT 'A not null column that shows name of a department. Administration,
Marketing, Purchasing, Human Resources, Shipping, IT, Executive, Public
Relations, Sales, Finance, and Accounting.',
`manager_id` int COMMENT 'Manager_id of a department. Foreign key to employee_id column of employees table. The manager_id column of the employee table references this column.',
`location_id` int COMMENT 'Location id where a department is located. Foreign key to location_id column of locations table.'
)
COMMENT 'Departments table that shows details of departments where employees
work. Contains 27 rows; references with locations, employees, and job_history tables.'
STORED AS PARQUET
LOCATION 'hdfs:///user/srperi/db/base_departments';


COMPUTE STATS base_departments;
