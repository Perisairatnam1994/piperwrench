#!/usr/bin/env bash


# Remove parquet data from incr
set -euo pipefail

DIRECTORY="hdfs:///user/srperi/db/incr_departments"

if $(hdfs dfs -test -d $DIRECTORY); then
	hdfs dfs -rm -r -f $DIRECTORY
else
	echo "Directory: $DIRECTORY does not exist, nothing to delete"
fi






spark-submit --deploy-mode client --master yarn --class io.phdata.pipewrench.dq.DataQualityApp /home/srperi/chs-pipewrench-data-quality/target/scala-2.11/pipewrench-data-quality-0.1-SNAPSHOT.jar --conf /home/srperi/pipewrench-2.1.0/output/pipeline/pipewrench-configuration.yml --table ~pipewrench-2.1.0/output/sqoop-parquet-hdfs-hive-merge-modified/departments
