
set sync_ddl=1;

USE `user_srperi`;

INSERT OVERWRITE TABLE `user_srperi`.`base_departments`
	SELECT `department_id`,
`department_name`,
`manager_id`,
`location_id`  FROM `user_srperi`.`report_departments`;
