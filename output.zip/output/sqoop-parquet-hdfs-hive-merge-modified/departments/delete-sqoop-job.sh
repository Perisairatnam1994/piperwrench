#!/bin/bash


set -euo pipefail

sqoop job --delete 'pipeline/dev/departments'

