
INSERT OVERWRITE TABLE `user_srperi`.`part_locations` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
`location_id`,
`street_address`,
`postal_code`,
`city`,
`state_province`,
`country_id`
FROM `user_srperi`.`stg_locations`;