
COMPUTE STATS `user_srperi`.`locations`;