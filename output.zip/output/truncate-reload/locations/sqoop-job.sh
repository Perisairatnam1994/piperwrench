#!/usr/bin/env bash

set -euo pipefail

sqoop import	 -D 'mapred.job.name="Sqoop Job - name: phdata-oracle environment: dev table: LOCATIONS"' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--driver 'oracle.jdbc.OracleDriver' \
	--delete-target-dir \
	--target-dir 'hdfs:///user/srperi/db/stg_locations/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_locations/' \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress \
	--compression-codec snappy \
	-m 1 \
	--map-column-java 'location_id=Integer' \
	--query 'SELECT
LOCATION_ID AS "location_id",
STREET_ADDRESS AS "street_address",
POSTAL_CODE AS "postal_code",
CITY AS "city",
STATE_PROVINCE AS "state_province",
COUNTRY_ID AS "country_id"
FROM HR.LOCATIONS
WHERE $CONDITIONS'