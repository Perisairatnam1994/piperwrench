
ALTER TABLE `user_srperi`.`locations` SET LOCATION 'hdfs:///user/srperi/db/part_locations/ingest_partition=${var:ingest_partition}/';