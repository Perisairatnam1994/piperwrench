
DROP TABLE IF EXISTS `user_srperi`.`part_locations` PURGE;