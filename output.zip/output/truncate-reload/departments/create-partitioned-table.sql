
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`part_departments` (
`department_id` int COMMENT 'Primary key column of departments table.',
`department_name` string COMMENT 'A not null column that shows name of a department. Administration,
Marketing, Purchasing, Human Resources, Shipping, IT, Executive, Public
Relations, Sales, Finance, and Accounting.',
`manager_id` int COMMENT 'Manager_id of a department. Foreign key to employee_id column of employees table. The manager_id column of the employee table references this column.',
`location_id` int COMMENT 'Location id where a department is located. Foreign key to location_id column of locations table.'
)
PARTITIONED BY (ingest_partition int)
COMMENT 'Departments table that shows details of departments where employees
work. Contains 27 rows; references with locations, employees, and job_history tables.'
STORED AS PARQUET
LOCATION 'hdfs:///user/srperi/db/part_departments'
