
ALTER TABLE `user_srperi`.`departments` SET LOCATION 'hdfs:///user/srperi/db/part_departments/ingest_partition=${var:ingest_partition}/';