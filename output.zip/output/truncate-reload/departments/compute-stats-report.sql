
COMPUTE STATS `user_srperi`.`departments`;