
INSERT OVERWRITE TABLE `user_srperi`.`part_departments` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
`department_id`,
`department_name`,
`manager_id`,
`location_id`
FROM `user_srperi`.`stg_departments`;