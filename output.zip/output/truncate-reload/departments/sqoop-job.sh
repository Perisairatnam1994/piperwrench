#!/usr/bin/env bash

set -euo pipefail

sqoop import	 -D 'mapred.job.name="Sqoop Job - name: phdata-oracle environment: dev table: DEPARTMENTS"' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--driver 'oracle.jdbc.OracleDriver' \
	--delete-target-dir \
	--target-dir 'hdfs:///user/srperi/db/stg_departments/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_departments/' \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress \
	--compression-codec snappy \
	-m 1 \
	--map-column-java 'department_id=Integer,manager_id=Integer,location_id=Integer' \
	--query 'SELECT
DEPARTMENT_ID AS "department_id",
DEPARTMENT_NAME AS "department_name",
MANAGER_ID AS "manager_id",
LOCATION_ID AS "location_id"
FROM HR.DEPARTMENTS
WHERE $CONDITIONS'