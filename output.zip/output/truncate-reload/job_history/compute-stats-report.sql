
COMPUTE STATS `user_srperi`.`job_history`;