
INSERT OVERWRITE TABLE `user_srperi`.`part_job_history` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
`employee_id`,
CAST(`start_date` AS timestamp) AS `start_date`,
CAST(`end_date` AS timestamp) AS `end_date`,
`job_id`,
`department_id`
FROM `user_srperi`.`stg_job_history`;