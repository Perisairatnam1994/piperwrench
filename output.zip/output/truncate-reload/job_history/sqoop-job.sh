#!/usr/bin/env bash

set -euo pipefail

sqoop import	 -D 'mapred.job.name="Sqoop Job - name: phdata-oracle environment: dev table: JOB_HISTORY"' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--driver 'oracle.jdbc.OracleDriver' \
	--delete-target-dir \
	--target-dir 'hdfs:///user/srperi/db/stg_job_history/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_job_history/' \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress \
	--compression-codec snappy \
	-m 1 \
	--map-column-java 'employee_id=Integer,department_id=Integer' \
	--query 'SELECT
EMPLOYEE_ID AS "employee_id",
START_DATE AS "start_date",
END_DATE AS "end_date",
JOB_ID AS "job_id",
DEPARTMENT_ID AS "department_id"
FROM HR.JOB_HISTORY
WHERE $CONDITIONS'