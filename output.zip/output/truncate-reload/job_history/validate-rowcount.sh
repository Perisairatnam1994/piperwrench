#!/bin/bash


set -euo pipefail

SOURCE_ROWCOUNT=

# Count number of rows in source
DRIVER="oracle.jdbc.OracleDriver"
if [[ $DRIVER =~ "sqlserver" ]]; then
  SOURCE_ROWCOUNT=$(sqoop-eval	 --connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL'	 --username 'HR'	 --password-file hdfs:///user/srperi/oracle_password	 --query 'select count(*) FROM HR.[JOB_HISTORY]' | grep -o '[[:digit:]]*')
else
  SOURCE_ROWCOUNT=$(sqoop-eval	 --connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL'	 --username 'HR'	 --password-file hdfs:///user/srperi/oracle_password	 --query 'select count(*) FROM HR.JOB_HISTORY' | grep -o '[[:digit:]]*')
fi

# Check target table
TARGET_ROWCOUNT=$(impala-shell -i worker1.valhalla.phdata.io -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/x509/truststore.pem --query "SELECT COUNT(*) FROM user_srperi.\`job_history\`;" -B 2> /dev/null)

echo "source count: $SOURCE_ROWCOUNT"
echo "target count: $TARGET_ROWCOUNT"

if [ "$TARGET_ROWCOUNT" -ne "$SOURCE_ROWCOUNT" ]; then
  echo "TARGET AND SOURCE ROW COUNTS DO NOT MATCH"
  exit 1
fi

