
ALTER TABLE `user_srperi`.`job_history` SET LOCATION 'hdfs:///user/srperi/db/part_job_history/ingest_partition=${var:ingest_partition}/';