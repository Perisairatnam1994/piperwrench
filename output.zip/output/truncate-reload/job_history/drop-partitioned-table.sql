
DROP TABLE IF EXISTS `user_srperi`.`part_job_history` PURGE;