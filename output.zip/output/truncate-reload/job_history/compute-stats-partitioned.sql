
COMPUTE INCREMENTAL STATS `user_srperi`.`part_job_history`;