
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`stg_countries` (
`country_id` string COMMENT 'Primary key of countries table.',
`country_name` string COMMENT 'Country name',
`region_id` string COMMENT 'Region ID for the country. Foreign key to region_id column in the departments table.'
)
COMMENT 'country table. Contains 25 rows. References with locations table.'
STORED AS AVRO
LOCATION 'hdfs:///user/srperi/db/stg_countries'
TBLPROPERTIES(
'avro.schema.url' = 'hdfs:///user/srperi/db/stg_countries/.meta/stg_countries.avsc'
)
