
ALTER TABLE `user_srperi`.`countries` SET LOCATION 'hdfs:///user/srperi/db/part_countries/ingest_partition=${var:ingest_partition}/';