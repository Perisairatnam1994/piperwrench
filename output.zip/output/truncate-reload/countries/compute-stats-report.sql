
COMPUTE STATS `user_srperi`.`countries`;