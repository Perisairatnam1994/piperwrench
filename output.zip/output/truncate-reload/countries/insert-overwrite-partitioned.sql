
INSERT OVERWRITE TABLE `user_srperi`.`part_countries` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
`country_id`,
`country_name`,
`region_id`
FROM `user_srperi`.`stg_countries`;