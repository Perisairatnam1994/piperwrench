
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`countries` (
`country_id` string COMMENT 'Primary key of countries table.',
`country_name` string COMMENT 'Country name',
`region_id` string COMMENT 'Region ID for the country. Foreign key to region_id column in the departments table.'
)
COMMENT 'country table. Contains 25 rows. References with locations table.'
STORED AS PARQUET
LOCATION 'hdfs:///user/srperi/db/countries'
