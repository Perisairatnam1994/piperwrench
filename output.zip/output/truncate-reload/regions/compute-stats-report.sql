
COMPUTE STATS `user_srperi`.`regions`;