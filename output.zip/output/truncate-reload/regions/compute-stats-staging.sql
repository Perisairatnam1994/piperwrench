
COMPUTE STATS `user_srperi`.`stg_regions`;