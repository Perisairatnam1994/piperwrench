
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`regions` (
`region_id` string COMMENT '',
`region_name` string COMMENT ''
)
COMMENT ''
STORED AS PARQUET
LOCATION 'hdfs:///user/srperi/db/regions'
