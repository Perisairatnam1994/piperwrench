
INSERT OVERWRITE TABLE `user_srperi`.`part_regions` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
`region_id`,
`region_name`
FROM `user_srperi`.`stg_regions`;