
COMPUTE INCREMENTAL STATS `user_srperi`.`part_regions`;