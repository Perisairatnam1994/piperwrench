
ALTER TABLE `user_srperi`.`regions` SET LOCATION 'hdfs:///user/srperi/db/part_regions/ingest_partition=${var:ingest_partition}/';