
DROP TABLE IF EXISTS `user_srperi`.`part_regions` PURGE;