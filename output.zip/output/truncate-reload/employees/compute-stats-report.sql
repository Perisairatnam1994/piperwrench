
COMPUTE STATS `user_srperi`.`employees`;