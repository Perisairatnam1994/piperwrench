
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`employees` (
`employee_id` int COMMENT 'Primary key of employees table.',
`first_name` string COMMENT 'First name of the employee. A not null column.',
`last_name` string COMMENT 'Last name of the employee. A not null column.',
`email` string COMMENT 'Email id of the employee',
`phone_number` string COMMENT 'Phone number of the employee; includes country code and area code',
`hire_date` timestamp COMMENT 'Date when the employee started on this job. A not null column.',
`job_id` string COMMENT 'Current job of the employee; foreign key to job_id column of the
jobs table. A not null column.',
`salary` DECIMAL(8, 2) COMMENT 'Monthly salary of the employee. Must be greater
than zero (enforced by constraint emp_salary_min)',
`commission_pct` DECIMAL(2, 2) COMMENT 'Commission percentage of the employee; Only employees in sales
department elgible for commission percentage',
`manager_id` int COMMENT 'Manager id of the employee; has same domain as manager_id in
departments table. Foreign key to employee_id column of employees table.
(useful for reflexive joins and CONNECT BY query)',
`department_id` int COMMENT 'Department id where employee works; foreign key to department_id
column of the departments table'
)
COMMENT 'employees table. Contains 107 rows. References with departments,
jobs, job_history tables. Contains a self reference.'
STORED AS PARQUET
LOCATION 'hdfs:///user/srperi/db/employees'
