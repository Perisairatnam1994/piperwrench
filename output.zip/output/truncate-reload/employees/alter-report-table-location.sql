
ALTER TABLE `user_srperi`.`employees` SET LOCATION 'hdfs:///user/srperi/db/part_employees/ingest_partition=${var:ingest_partition}/';