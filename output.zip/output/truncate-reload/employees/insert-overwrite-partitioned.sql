
INSERT OVERWRITE TABLE `user_srperi`.`part_employees` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
`employee_id`,
`first_name`,
`last_name`,
`email`,
`phone_number`,
CAST(`hire_date` AS timestamp) AS `hire_date`,
`job_id`,
CAST(`salary` AS DECIMAL(8, 2)) AS `salary`,
CAST(`commission_pct` AS DECIMAL(2, 2)) AS `commission_pct`,
`manager_id`,
`department_id`
FROM `user_srperi`.`stg_employees`;