
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`stg_employees` (
`employee_id` int COMMENT 'Primary key of employees table.',
`first_name` string COMMENT 'First name of the employee. A not null column.',
`last_name` string COMMENT 'Last name of the employee. A not null column.',
`email` string COMMENT 'Email id of the employee',
`phone_number` string COMMENT 'Phone number of the employee; includes country code and area code',
`hire_date` bigint COMMENT 'Date when the employee started on this job. A not null column.',
`job_id` string COMMENT 'Current job of the employee; foreign key to job_id column of the
jobs table. A not null column.',
`salary` string COMMENT 'Monthly salary of the employee. Must be greater
than zero (enforced by constraint emp_salary_min)',
`commission_pct` string COMMENT 'Commission percentage of the employee; Only employees in sales
department elgible for commission percentage',
`manager_id` int COMMENT 'Manager id of the employee; has same domain as manager_id in
departments table. Foreign key to employee_id column of employees table.
(useful for reflexive joins and CONNECT BY query)',
`department_id` int COMMENT 'Department id where employee works; foreign key to department_id
column of the departments table'
)
COMMENT 'employees table. Contains 107 rows. References with departments,
jobs, job_history tables. Contains a self reference.'
STORED AS AVRO
LOCATION 'hdfs:///user/srperi/db/stg_employees'
TBLPROPERTIES(
'avro.schema.url' = 'hdfs:///user/srperi/db/stg_employees/.meta/stg_employees.avsc'
)
