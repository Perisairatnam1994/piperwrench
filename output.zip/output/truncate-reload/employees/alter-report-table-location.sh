#!/usr/bin/env bash

set -euo pipefail

PARTITION_FILE="hdfs:///user/srperi/db/part_employees/.latest-partition"
PARTITION_NUMBER=1

if $(hdfs dfs -test -e $PARTITION_FILE); then
	PARTITION_NUMBER=$(hdfs dfs -cat $PARTITION_FILE)

	if [[ $PARTITION_NUMBER -eq 4 ]]; then
		PARTITION_NUMBER=1
	else
		PARTITION_NUMBER=$((PARTITION_NUMBER+1))
	fi
fi

impala-shell -i worker1.valhalla.phdata.io -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/x509/truststore.pem -f insert-overwrite-partitioned.sql --var=ingest_partition=$PARTITION_NUMBER

if [ $? -eq 0 ]; then
	impala-shell -i worker1.valhalla.phdata.io -d default -k --ssl --ca_cert=/opt/cloudera/security/pki/x509/truststore.pem -f alter-report-table-location.sql --var=ingest_partition=$PARTITION_NUMBER

	if $(hdfs dfs -test -e $PARTITION_FILE); then
		hdfs dfs -rm -skipTrash $PARTITION_FILE
	fi

	echo $PARTITION_NUMBER | hdfs dfs -put - $PARTITION_FILE
fi