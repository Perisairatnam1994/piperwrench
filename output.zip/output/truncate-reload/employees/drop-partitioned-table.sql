
DROP TABLE IF EXISTS `user_srperi`.`part_employees` PURGE;