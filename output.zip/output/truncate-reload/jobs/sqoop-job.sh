#!/usr/bin/env bash

set -euo pipefail

sqoop import	 -D 'mapred.job.name="Sqoop Job - name: phdata-oracle environment: dev table: JOBS"' \
	--connect 'jdbc:oracle:thin:@oraclerds.caewceohkuoi.us-east-1.rds.amazonaws.com:1521:ORCL' \
	--username 'HR' \
	--password-file 'hdfs:///user/srperi/oracle_password' \
	--driver 'oracle.jdbc.OracleDriver' \
	--delete-target-dir \
	--target-dir 'hdfs:///user/srperi/db/stg_jobs/' \
	--temporary-rootdir 'hdfs:///user/srperi/db/stg_jobs/' \
	--as-avrodatafile \
	--fetch-size 10000 \
	--compress \
	--compression-codec snappy \
	-m 1 \
	--map-column-java 'min_salary=Integer,max_salary=Integer' \
	--query 'SELECT
JOB_ID AS "job_id",
JOB_TITLE AS "job_title",
MIN_SALARY AS "min_salary",
MAX_SALARY AS "max_salary"
FROM HR.JOBS
WHERE $CONDITIONS'