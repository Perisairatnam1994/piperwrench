
INSERT OVERWRITE TABLE `user_srperi`.`part_jobs` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
`job_id`,
`job_title`,
`min_salary`,
`max_salary`
FROM `user_srperi`.`stg_jobs`;