
ALTER TABLE `user_srperi`.`jobs` SET LOCATION 'hdfs:///user/srperi/db/part_jobs/ingest_partition=${var:ingest_partition}/';