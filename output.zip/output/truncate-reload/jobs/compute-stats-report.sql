
COMPUTE STATS `user_srperi`.`jobs`;