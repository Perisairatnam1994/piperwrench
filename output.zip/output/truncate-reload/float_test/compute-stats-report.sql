
COMPUTE STATS `user_srperi`.`float_test`;