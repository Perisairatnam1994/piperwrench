
ALTER TABLE `user_srperi`.`float_test` SET LOCATION 'hdfs:///user/srperi/db/part_float_test/ingest_partition=${var:ingest_partition}/';