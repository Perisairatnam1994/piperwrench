
COMPUTE INCREMENTAL STATS `user_srperi`.`part_float_test`;