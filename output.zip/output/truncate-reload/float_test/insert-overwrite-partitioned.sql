
INSERT OVERWRITE TABLE `user_srperi`.`part_float_test` PARTITION (ingest_partition=${var:ingest_partition})
SELECT
CAST(`id` AS DECIMAL(38, 0)) AS `id`,
`float_value`
FROM `user_srperi`.`stg_float_test`;