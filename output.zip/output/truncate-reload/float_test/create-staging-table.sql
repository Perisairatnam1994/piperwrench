
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`stg_float_test` (
`id` string COMMENT 'Primary Key',
`float_value` float COMMENT 'Float value'
)
COMMENT 'Testing float values in Oracle tables'
STORED AS AVRO
LOCATION 'hdfs:///user/srperi/db/stg_float_test'
TBLPROPERTIES(
'avro.schema.url' = 'hdfs:///user/srperi/db/stg_float_test/.meta/stg_float_test.avsc'
)
