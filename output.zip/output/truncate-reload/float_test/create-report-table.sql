
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`float_test` (
`id` DECIMAL(38, 0) COMMENT 'Primary Key',
`float_value` float COMMENT 'Float value'
)
COMMENT 'Testing float values in Oracle tables'
STORED AS PARQUET
LOCATION 'hdfs:///user/srperi/db/float_test'
