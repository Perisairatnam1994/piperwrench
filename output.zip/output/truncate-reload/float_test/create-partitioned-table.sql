
set sync_ddl=1;
CREATE TABLE IF NOT EXISTS `user_srperi`.`part_float_test` (
`id` DECIMAL(38, 0) COMMENT 'Primary Key',
`float_value` float COMMENT 'Float value'
)
PARTITIONED BY (ingest_partition int)
COMMENT 'Testing float values in Oracle tables'
STORED AS PARQUET
LOCATION 'hdfs:///user/srperi/db/part_float_test'
